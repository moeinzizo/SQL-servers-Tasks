﻿


-------پیدا کردن مواردی که در جدول انبارها موجود نبوده است
--select product_id from production.products 
--except
--select product_id from production.stocks where store_id=2


---- مواردی که در جدول انبار ها موجود نبود  در جدول با موجودی صفر برای هر فروشگاه اضافه شد

----- یافتن speedSalesیا سرعت فروش برای هر فروشگاه در هر مغازه 
select o.store_id,oi.product_id,cast(sum(oi.quantity) as float) tedad_forosh ,count(o.order_date) as days , (cast(sum(oi.quantity) as float)/count(o.order_date)) as speedsales
from sales.orders o join sales.order_items oi on o.order_id=oi.order_id 
group by oi.product_id,o.store_id order by o.store_id,oi.product_id
----
--- برای راحتی همه را به داخل یک ویو انتقال میدهیم.

CREATE VIEW speedsales AS
select o.store_id,oi.product_id,cast(sum(oi.quantity) as float) tedad_forosh ,count(o.order_date) as days , (cast(sum(oi.quantity) as float)/count(o.order_date)) as speedsales
from sales.orders o join sales.order_items oi on o.order_id=oi.order_id 
group by oi.product_id,o.store_id;

----


select s.store_id,s.product_id,
case 
when ss.store_id is null then null
else floor(s.quantity/ss.speedsales)
end as daysof_mandegari
from production.stocks s left join speedsales ss on s.store_id=ss.store_id and s.product_id=ss.product_id order by s.store_id,s.product_id
